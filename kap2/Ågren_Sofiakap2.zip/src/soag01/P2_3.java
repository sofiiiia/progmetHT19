/**
 * 
 */
package soag01;

/**testprogram
 * 
 * @author 19soag01 (Sofia Ågren)
 * @version 2019-09-13
 *
 */
public class P2_3 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		int x = 5;
		
		System.out.println(x*x);
		System.out.println(x*x*x);
		System.out.println(Math.pow(x,4));
	}

}
