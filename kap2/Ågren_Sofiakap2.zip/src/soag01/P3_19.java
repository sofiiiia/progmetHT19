/**
 * 
 */
package soag01;

import java.util.Scanner;

/**Testprogram
 * 
 * @author 19soag01 (Sofia Ågren)
 * @version 219-09-13
 *
 */
public class P3_19 
{

	/**
	 * @param args
	 */
	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		System.out.println("Please enter an integer between 1 and 12");
		
		String month = "January   February  March     April     May       June      July     August    September October   November  December "
		int x = 
		input.close();

	}

}
